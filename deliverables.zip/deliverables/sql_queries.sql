
select ip from parserdb.parser_log where requests >= 500 and period like "2017-01-01%"

select ip from parserdb.parser_log where requests >= 200 and period between "2017-01-01 06:00:00" and "2017-01-01 07:00:00"

select id, requests, comment, period from parserdb.parser_log where ip="192.168.53.68"

